#include "motion_primitives_planner/motion_primitives_planner_node.hpp"

/* ----- Class Functions ----- */
MotionPlanner::MotionPlanner(ros::NodeHandle& nh) : nh_(nh)
{
  // Subscriber
  subOccupancyGrid = nh.subscribe("/map/local_map/obstacle",1, &MotionPlanner::CallbackOccupancyGrid, this);
  // Publisher
  pubSelectedMotion = nh_.advertise<sensor_msgs::PointCloud2>("/points/selected_motion", 1, true);
  pubMotionPrimitives = nh_.advertise<sensor_msgs::PointCloud2>("/points/motion_primitives", 1, true);
  pubCommand = nh_.advertise<ackermann_msgs::AckermannDrive>("/car_1/command", 1, true);
  
};

MotionPlanner::~MotionPlanner() 
{    
    ROS_INFO("MotionPlanner destructor.");
}

/* ----- ROS Functions ----- */

void MotionPlanner::CallbackOccupancyGrid(const nav_msgs::OccupancyGrid& msg)
{
  // Subscribe to the map messages
  localMap = msg;
  // The origin of the map [m, m, rad].  This is the real-world pose of the cell (0,0) in the map.
  this->origin_x = msg.info.origin.position.x;
  this->origin_y = msg.info.origin.position.y;
  // Frame id of the map
  this->frame_id = msg.header.frame_id;
  // The map resolution [m/cell]
  this->mapResol = msg.info.resolution;
  // message flag
  bGetMap = true;
}

void MotionPlanner::PublishSelectedMotion(std::vector<Node> motionMinCost)
{
  // publish selected motion primitive as point cloud
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in_ptr(new pcl::PointCloud<pcl::PointXYZI>);

  for (auto motion : motionMinCost) {
    pcl::PointXYZI pointTmp;
    pointTmp.x = motion.x;
    pointTmp.y = motion.y;
    cloud_in_ptr->points.push_back(pointTmp);
  }

  sensor_msgs::PointCloud2 motionCloudMsg;
  pcl::toROSMsg(*cloud_in_ptr, motionCloudMsg);
  motionCloudMsg.header.frame_id = this->frame_id;
  motionCloudMsg.header.stamp = ros::Time::now();
  pubSelectedMotion.publish(motionCloudMsg);
}

void MotionPlanner::PublishMotionPrimitives(std::vector<std::vector<Node>> motionPrimitives)
{
  // publish motion primitives as point cloud
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in_ptr(new pcl::PointCloud<pcl::PointXYZI>);

  for (auto& motionPrimitive : motionPrimitives) {
    for (auto motion : motionPrimitive) {
      pcl::PointXYZI pointTmp;
      pointTmp.x = motion.x;
      pointTmp.y = motion.y;
      cloud_in_ptr->points.push_back(pointTmp);
    }
  }
  
  sensor_msgs::PointCloud2 motionPrimitivesCloudMsg;
  pcl::toROSMsg(*cloud_in_ptr, motionPrimitivesCloudMsg);
  motionPrimitivesCloudMsg.header.frame_id = this->frame_id;
  motionPrimitivesCloudMsg.header.stamp = ros::Time::now();
  pubMotionPrimitives.publish(motionPrimitivesCloudMsg);
}

void MotionPlanner::PublishCommand(std::vector<Node> motionMinCost, double speedfactor)
{
  /*
    TODO: Publish control commands
    - Two components in the AckermannDrive message is used: steering_angle and speed.
    - Compute steering angle using your controller or other method.
    - Calculate proper speed command
    - Publish data  
  */
  
  
      if (motionMinCost.empty()) {
        ROS_WARN("Empty motion primitive received. Cannot publish command.");
        return;
    }
  ackermann_msgs::AckermannDrive command;
  command.steering_angle = motionMinCost.front().delta;
  //command.speed = 0.5 * std::exp(-0.05 * std::abs(command.steering_angle)) ;
	// Calculate the speed based on the steering angle
	double maxSpeed = 0.6; // Maximum speed when steering angle is 0
	// double minSpeed = 0.1; // Minimum speed when steering angle is maximum (or any other value you desire)
	// double steeringAngle = std::abs(motionMinCost.front().delta); // Absolute value of the steering angle

	// Calculate the speed based on the steering angle, adjust the coefficients as needed
	// command.speed = maxSpeed * exp(-2.3 * std::abs(command.steering_angle) - 0.5 / (speedfactor + 0.1) ;
	command.speed = maxSpeed * exp(-2.3 * std::abs(command.steering_angle)) ;
  pubCommand.publish(command);
  std::cout << "command steer/speed : " << command.steering_angle*180/M_PI << " " << command.speed << std::endl;
  // std::cout << "speedfactor: " << speedfactor << ", command.speed: " << command.speed << std::endl;
}

/* ----- Algorithm Functions ----- */

void MotionPlanner::Plan()
{
  // Motion generation
  std::vector<std::vector<Node>> motionPrimitives = GenerateMotionPrimitives(this->localMap);
  
  // Select motion, motionData
  std::pair<std::vector<Node>, double> motionData = SelectMotion(motionPrimitives);

  // Publish data
  PublishData(motionData, motionPrimitives);
}

std::vector<std::vector<Node>> MotionPlanner::GenerateMotionPrimitives(nav_msgs::OccupancyGrid localMap)
{
  /*
    TODO: Generate motion primitives
    - you can change the below process if you need.
    - you can calculate cost of each motion if you need.
  */

  // initialize motion primitives
  std::vector<std::vector<Node>> motionPrimitives;

  // number of candidates
  int num_candidates = this->MAX_DELTA*2 / this->DELTA_RESOL; // *2 for considering both left/right direction

  // max progress of each motion
  double maxProgress = this->MAX_PROGRESS;
  for (int i=0; i<num_candidates+1; i++) {
    // current steering delta
    double angle_delta = this->MAX_DELTA - i * this->DELTA_RESOL;

    // init start node
    Node startNode(0, 0, 0, angle_delta, 0, 0, 0, -1, false);
    
    // rollout to generate motion
    std::vector<Node> motionPrimitive = RolloutMotion(startNode, maxProgress, localMap);

    // add current motionPrimitive
    motionPrimitives.push_back(motionPrimitive);
  }

  return motionPrimitives;
}

std::vector<Node> MotionPlanner::RolloutMotion(Node startNode,
                                              double maxProgress,
                                              nav_msgs::OccupancyGrid localMap)
{
  /*
    TODO: rollout to generate a motion primitive based on the current steering angle
    - calculate cost terms here if you need
    - check collision / sensor range if you need
    1. Update motion node using current steering angle delta based on the vehicle kinematics equation.
    2. collision checking
    3. range checking
  */

    std::vector<Node> motionPrimitive;
    Node currMotionNode = startNode;
    double progress = 0;

    while (progress < maxProgress) {
        // Update motion node using vehicle kinematics
        double delta_t = this->TIME_RESOL;
        double velocity = this->MOTION_VEL;

        // Assuming a simple bicycle model for vehicle kinematics
        currMotionNode.x += velocity * cos(currMotionNode.yaw) * delta_t;
        currMotionNode.y += velocity * sin(currMotionNode.yaw) * delta_t;
        currMotionNode.yaw += velocity / this->WHEELBASE * tan(currMotionNode.delta) * delta_t;

        // Collision checking
        Node collisionPointNodeMap = LocalToMapCorrdinate(currMotionNode);
        if (CheckCollision(collisionPointNodeMap, localMap)) {
            // Handle collision case (e.g., break the loop or mark the node)
            break;
        }

        // Range checking
        double LOS_DIST = sqrt(currMotionNode.x * currMotionNode.x + currMotionNode.y * currMotionNode.y);
        double LOS_YAW = atan2(currMotionNode.y, currMotionNode.x);

        if (LOS_DIST > this->MAX_SENSOR_RANGE || abs(LOS_YAW) > this->FOV * 0.5) {
            // Handle out-of-range case
            break;
        }

        // Append collision-free motion to the motion primitive
        motionPrimitive.push_back(currMotionNode);

        // Update progress
        progress += velocity * delta_t; // Or another appropriate measure of progress
    }

    return motionPrimitive;
}


////////////////////////////////////////////////////Important function//////////////////////
std::pair<std::vector<Node>, double> MotionPlanner::SelectMotion(std::vector<std::vector<Node>> motionPrimitives)
{

  /*
  TODO: select the minimum cost motion primitive
  
    1. Calculate cost terms
    2. Calculate total cost (weighted sum of all cost terms)
    3. Compare & Find minimum cost (double minCost) & minimum cost motion (std::vector<Node> motionMinCost)
    4. Return minimum cost motion
  */


  // Initialization
  double minCost = std::numeric_limits<double>::max();
  std::vector<Node> motionMinCost; // Initialize as an empty vector
  double speedfactor = 0.0;

  // check size of motion primitives
  if (!motionPrimitives.empty())  {
  	
    // Iterate all motion primitive (motionPrimitive) in motionPrimitives
    for (auto& motionPrimitive : motionPrimitives) {
      // 1. Calculate cost terms
      ;
      double cost_collision = 0.0;
      for (const auto& node : motionPrimitive) {
      	if (CheckCollision(node, localMap)) {
          cost_collision = std::numeric_limits<double>::max(); // Set to a high cost for collision
          break;
      	}
      }

	double cost_steering = 0.0;
	for (size_t i = 1; i < motionPrimitive.size(); ++i) {
	    double steering_change = std::abs(motionPrimitive[i].yaw- motionPrimitive[i - 1].yaw);
	    cost_steering += steering_change;
	    /*std::cout << "Delta[" << i << "]: " << motionPrimitive[i].delta << ", Steering Change: " << steering_change << ", Cost Steering: " << cost_steering << std::endl;*/
	}



      // Calculate traversability term based on the length of the motion primitive
      double cost_traversability = 0.0;
      for (size_t i = 1; i < motionPrimitive.size(); ++i) {
	double dx = motionPrimitive[i].x - motionPrimitive[i - 1].x;
	double dy = motionPrimitive[i].y - motionPrimitive[i - 1].y;
	double segment_length = std::sqrt(dx * dx + dy * dy);
	cost_traversability += segment_length;
      }
      speedfactor = cost_traversability;
      cost_traversability = 1.0 / (cost_traversability + 0.1);
      
	double weight_collision = 20.0;
	// double weight_steering = 10.0;
	// double weight_progress = 2.0;
	double weight_traversability = 30.0;
    	double cost_total = weight_collision * cost_collision +
                       weight_traversability * cost_traversability;
                        
                      //weight_steering * cost_steering +
                        
      // 3. Compare & Find minimum cost & minimum cost motion
      if (cost_total < minCost) {
                minCost = cost_total;
                motionMinCost = motionPrimitive;
                // speedfactor = cost_traversability;
      }
    }
  }
  // 4. Return minimum cost motion
  return std::make_pair(motionMinCost, speedfactor);
}


/* ----- Util Functions ----- */

bool MotionPlanner::CheckCollision(Node currentNodeMap, nav_msgs::OccupancyGrid localMap)
{
  /*
    TODO: check collision of the current node
    - the position x of the node should be in a range of [0, map width]
    - the position y of the node should be in a range of [0, map height]
    - check all map values within the inflation area of the current node
    e.g.,

    for loop i in range(0, inflation_size)
      for loop j in range(0, inflation_size)
        tmp_x := currentNodeMap.x + i - 0.5*inflation_size <- you need to check whether this tmp_x is in [0, map width]
        tmp_y := currentNodeMap.y + j - 0.5*inflation_size <- you need to check whether this tmp_x is in [0, map height]
        map_index := "index of the grid at the position (tmp_x, tmp_y)" <-- map_index should be int, not double!
        map_value = static_cast<int16_t>(localMap.data[map_index])
        if (map_value > map_value_threshold) OR (map_value < 0)
          return true
    return false

    - use params in header file: INFLATION_SIZE, OCCUPANCY_THRES
  */
    int map_width = localMap.info.width;
    int map_height = localMap.info.height;
    float resolution = localMap.info.resolution; // Assuming resolution is needed for grid cell size

    for (int i = 0; i < INFLATION_SIZE; ++i)
    {
        for (int j = 0; j < INFLATION_SIZE; ++j)
        {
            int tmp_x = currentNodeMap.x + i - 0.5 * INFLATION_SIZE;
            int tmp_y = currentNodeMap.y + j - 0.5 * INFLATION_SIZE;

            // Check if tmp_x and tmp_y are within map boundaries
            if (tmp_x < 0 || tmp_x >= map_width || tmp_y < 0 || tmp_y >= map_height)
            {
                continue; // Skip this iteration as it's outside the map boundary
            }

            // Calculate the map index
            int map_index = tmp_y * map_width + tmp_x; // Row-major order assumed

            // Ensure index is within the bounds of the map data array
            if (map_index < 0 || map_index >= localMap.data.size())
            {
                continue;
            }

            int16_t map_value = static_cast<int16_t>(localMap.data[map_index]);

            // Check if the map value indicates an obstacle
            if (map_value > OCCUPANCY_THRES || map_value < 0)
            {
                return true; // Collision detected
            }
        }
    }
  return false;
}

bool MotionPlanner::CheckRunCondition()
{
  if (this->bGetMap) {
    return true;
  }
  else {
    std::cout << "Run condition is not satisfied!!!" << std::endl;
    return false;
  }
}

Node MotionPlanner::LocalToMapCorrdinate(Node nodeLocal)
{
  /*
    TODO: Transform from local to occupancy grid map coordinate
    - local coordinate ([m]): x [map min x, map max x], y [map min y, map max y]
    - map coordinate ([cell]): x [0, map width], y [map height]
    - convert [m] to [cell] using map resolution ([m]/[cell])
  */
  // Copy data nodeLocal to nodeMap
  Node nodeMap;
  memcpy(&nodeMap, &nodeLocal, sizeof(struct Node));
  // Transform from local (min x, max x) [m] to map (0, map width) [grid] coordinate
  nodeMap.x = static_cast<int>((nodeLocal.x - this->mapMinX) / this->mapResol);
  // Transform from local (min y, max y) [m] to map (0, map height) [grid] coordinate
  nodeMap.y = static_cast<int>((nodeLocal.y - this->mapMinY) / this->mapResol);

  return nodeMap;
}


/* ----- Publisher ----- */

void MotionPlanner::PublishData(std::pair<std::vector<Node>, double> motionData, std::vector<std::vector<Node>> motionPrimitives)
{
	std::vector<Node> motionMinCost = motionData.first;
	double speedfactor = motionData.second;
	
  // Publisher
  // - visualize selected motion primitive
  PublishSelectedMotion(motionMinCost);

  // - visualize motion primitives
  PublishMotionPrimitives(motionPrimitives);

  // - publish command
  PublishCommand(motionMinCost, speedfactor);
}

/* ----- Main ----- */

int main(int argc, char* argv[])
{ 
  std::cout << "start main process" << std::endl;

  ros::init(argc, argv, "motion_primitives_planner");
  // for subscribe
  ros::NodeHandle nh;
  ros::Rate rate(50.0);
  MotionPlanner MotionPlanner(nh);

  // Planning loop
  while (MotionPlanner.nh_.ok()) {
      // Spin ROS
      ros::spinOnce();
      // check run condition
      if (MotionPlanner.CheckRunCondition()) {
        // Run algorithm
        MotionPlanner.Plan();
      }
      rate.sleep();
  }

  return 0;

}
